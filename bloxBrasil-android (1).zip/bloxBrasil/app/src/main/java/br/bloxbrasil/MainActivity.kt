package br.bloxbrasil

import android.app.*
import android.content.*
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

const val RBX = "com.roblox.client"

class MainActivity : Activity() {
    private val bg = Color.parseColor("#F2F4F6")
    private val ink = Color.parseColor("#14263A")
    private val mute = Color.parseColor("#5A6B7C")
    private val acc = Color.parseColor("#1F5FBF")
    private val line = Color.parseColor("#D5DBE1")
    private val h = Handler(Looper.getMainLooper())
    private lateinit var content: FrameLayout
    private lateinit var navItems: List<TextView>
    private val views = mutableListOf<View>()
    private var cur = 0

    private val flagDefs = linkedMapOf<String, Map<String, Any>>(
        "Texturas em qualidade baixa" to mapOf("DFFlagTextureQualityOverrideEnabled" to true, "DFIntTextureQualityOverride" to 0),
        "Desativar suavização de bordas (MSAA)" to mapOf("FIntDebugForceMSAASamples" to 1),
        "Reduzir distância da grama" to mapOf("FIntFRMMinGrassDistance" to 0, "FIntFRMMaxGrassDistance" to 0),
        "Nível de qualidade gráfica mínimo" to mapOf("DFIntDebugFRMQualityLevelOverride" to 1),
        "Geometria em baixo detalhe" to mapOf("DFIntCSGLevelOfDetailSwitchingDistance" to 0, "DFIntCSGLevelOfDetailSwitchingDistanceL12" to 0,
            "DFIntCSGLevelOfDetailSwitchingDistanceL23" to 0, "DFIntCSGLevelOfDetailSwitchingDistanceL34" to 0),
        "Preferir Vulkan" to mapOf("FFlagDebugGraphicsPreferVulkan" to true)
    )
    private val flagKeys = flagDefs.keys.toList()
    private val flagOn = mutableSetOf(flagKeys[0], flagKeys[1], flagKeys[2])
    private val custom = linkedMapOf<String, String>()
    // Lista permitida pelo Roblox (anúncio de 29/09/2025). Pode ter mudado desde então.
    private val allow = setOf("DFIntCSGLevelOfDetailSwitchingDistance", "DFIntCSGLevelOfDetailSwitchingDistanceL12",
        "DFIntCSGLevelOfDetailSwitchingDistanceL23", "DFIntCSGLevelOfDetailSwitchingDistanceL34",
        "FFlagHandleAltEnterFullscreenManually", "DFFlagTextureQualityOverrideEnabled", "DFIntTextureQualityOverride",
        "FIntDebugForceMSAASamples", "DFFlagDisableDPIScale", "FFlagDebugGraphicsPreferD3D11", "FFlagDebugSkyGray",
        "DFFlagDebugPauseVoxelizer", "DFIntDebugFRMQualityLevelOverride", "FIntFRMMaxGrassDistance", "FIntFRMMinGrassDistance",
        "FFlagDebugGraphicsPreferVulkan", "FFlagDebugGraphicsPreferOpenGL", "FIntGrassMovementReducedMotionFactor")
    private val stepDefs = listOf("Liberar memória", "Silenciar notificações", "Verificar economia de bateria",
        "Gravar FastFlags", "Abrir Roblox")
    private val stepOn = stepDefs.toMutableSet()
    private var logTv: TextView? = null
    private var perfTv: TextView? = null
    private var fontInfo: TextView? = null
    private var fontPv: TextView? = null
    private val prefs by lazy { getSharedPreferences("bb", MODE_PRIVATE) }

    // ---------- helpers de interface ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(fill: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(6).toFloat()
    }
    private fun tv(t: String, sz: Float = 14f, c: Int = ink, bold: Boolean = false, mono: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = sz; setTextColor(c)
            if (mono) typeface = Typeface.MONOSPACE else if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    private fun btn(t: String, primary: Boolean = false, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 14f; minHeight = dp(48)
        setTextColor(if (primary) Color.WHITE else ink)
        background = box(if (primary) acc else Color.WHITE, if (primary) acc else line)
        setOnClickListener { f() }
    }
    private fun LinearLayout.put(v: View, bottom: Int = 12) =
        addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) })
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = box(Color.WHITE, line) }
    private fun page(title: String, lead: String): Pair<ScrollView, LinearLayout> {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(24)) }
        col.addView(tv(title, 20f, bold = true))
        col.addView(tv(lead, 13f, mute).apply { setPadding(0, dp(4), 0, dp(14)) })
        return ScrollView(this).apply { addView(col) } to col
    }
    private fun row(label: String, on: Boolean, f: (Boolean) -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8))
        addView(tv(label, 14f), LinearLayout.LayoutParams(0, -2, 1f))
        addView(Switch(context).apply { isChecked = on; setOnCheckedChangeListener { _, b -> f(b) } })
    }
    private fun log(m: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logTv?.append("$t  $m\n")
    }
    private fun installed(p: String) = try { packageManager.getPackageInfo(p, 0); true } catch (e: Exception) { false }

    // ---------- FastFlags ----------
    private fun fmt(v: Any) = if (v is Boolean) (if (v) "True" else "False") else v.toString()
    private fun loadCustom() {
        try { val o = JSONObject(prefs.getString("custom", "{}")!!); o.keys().forEach { custom[it] = o.getString(it) } } catch (e: Exception) { }
    }
    private fun saveCustom() = prefs.edit().putString("custom", JSONObject(custom as Map<*, *>).toString()).apply()
    private fun buildJson(): String {
        val o = JSONObject()
        flagDefs.filterKeys { it in flagOn }.values.forEach { m -> m.forEach { (k, v) -> o.put(k, fmt(v)) } }
        custom.forEach { (k, v) -> o.put(k, v) }
        return o.toString(2)
    }
    private fun su(script: String): Pair<Boolean, String> = try {
        val p = ProcessBuilder("su", "-c", script).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        (p.waitFor() == 0) to out.trim()
    } catch (e: Exception) { false to "root indisponível" }
    private fun applyRoot(done: (String) -> Unit) {
        val src = File(cacheDir, "ClientAppSettings.json"); src.writeText(buildJson())
        Thread {
            val d = "/data/data/$RBX/files/exe/ClientSettings"
            val u = "\$(stat -c %u /data/data/$RBX)"
            val (ok, out) = su("am force-stop $RBX; mkdir -p $d && cp ${src.absolutePath} $d/ClientAppSettings.json && " +
                "chown -R $u:$u $d && chmod 644 $d/ClientAppSettings.json; restorecon -R $d >/dev/null 2>&1; test -f $d/ClientAppSettings.json")
            val msg = if (ok) "FastFlags gravadas em $d. Abra o Roblox." else "Falhou: root ausente ou negado. Use Copiar JSON na aba FastFlags. $out"
            h.post { done(msg) }
        }.start()
    }

    // ---------- otimização ----------
    private fun doStep(s: String): String = when (s) {
        stepDefs[0] -> {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            var n = 0
            packageManager.getInstalledApplications(0).forEach { a ->
                if ((a.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && a.packageName != packageName && a.packageName != RBX) {
                    am.killBackgroundProcesses(a.packageName); n++
                }
            }
            "Encerramento solicitado para $n apps. O Android só finaliza processos em segundo plano."
        }
        stepDefs[1] -> {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                "Não perturbar ativado (somente prioridade)"
            } else {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                "Permissão necessária: libere o bloxBrasil e otimize de novo"
            }
        }
        stepDefs[2] ->
            if ((getSystemService(POWER_SERVICE) as PowerManager).isPowerSaveMode)
                "Economia de bateria ATIVA: reduz o desempenho. Desative nas configurações do Android."
            else "Economia de bateria desativada"
        stepDefs[3] -> { applyRoot { r -> log(r) }; "Aplicando FastFlags no Roblox (requer root)..." }
        else -> {
            val i = packageManager.getLaunchIntentForPackage(RBX)
            if (i != null) { startActivity(i); "Roblox iniciado" } else "Roblox não instalado"
        }
    }

    private fun runSteps(pb: ProgressBar, st: TextView, run: Button) {
        val list = stepDefs.filter { it in stepOn }
        logTv?.text = ""
        if (list.isEmpty()) { log("Nenhuma etapa selecionada"); return }
        run.isEnabled = false
        log(if (installed(RBX)) "Roblox encontrado ($RBX)" else "Roblox não instalado neste aparelho")
        fun next(i: Int) {
            if (i >= list.size) {
                pb.progress = 100; st.text = "Concluído"; log("${list.size} etapas processadas"); run.isEnabled = true; return
            }
            pb.progress = i * 100 / list.size; st.text = list[i]
            log("Executando: ${list[i]}"); log(doStep(list[i]))
            h.postDelayed({ next(i + 1) }, 700)
        }
        next(0)
    }

    // ---------- telas ----------
    private fun otimizar(): View {
        val (sv, col) = page("Otimizar Roblox", "Prepara o aparelho para o jogo e registra cada etapa. Somente o Roblox é o alvo.")
        val c = card()
        stepDefs.forEach { s -> c.addView(row(s, s in stepOn) { b -> if (b) stepOn.add(s) else stepOn.remove(s) }) }
        col.put(c)
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val st = tv("Aguardando", 12f, mute)
        val run = btn("Iniciar otimização", true) { }
        run.setOnClickListener { runSteps(pb, st, run) }
        col.put(run, 8); col.put(pb, 2); col.put(st, 12)
        val lc = card().apply { setPadding(dp(14), dp(12), dp(14), dp(12)) }
        logTv = tv("Nenhuma otimização executada.", 12f, mute, mono = true)
        lc.addView(logTv); col.put(lc)
        col.put(btn("Restaurar notificações") {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
        }, 8)
        col.put(btn("Limpar cache do Roblox (abre Configurações)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$RBX")))
        })
        return sv
    }

    private fun desempenho(): View {
        val (sv, col) = page("Desempenho do aparelho", "Leituras reais, atualizadas a cada 2 segundos.")
        val c = card()
        perfTv = tv("", 14f).apply { setPadding(dp(14), dp(12), dp(14), dp(12)); setLineSpacing(0f, 1.4f) }
        c.addView(perfTv); col.put(c); tickPerf()
        return sv
    }

    private fun tickPerf() {
        val t = perfTv ?: return
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = (b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 / (b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        @Suppress("DEPRECATION") val hz = windowManager.defaultDisplay.refreshRate
        val eco = (getSystemService(POWER_SERVICE) as PowerManager).isPowerSaveMode
        t.text = "Memória livre: ${mi.availMem / 1048576} MB de ${mi.totalMem / 1048576} MB\n" +
            "Núcleos de processamento: ${Runtime.getRuntime().availableProcessors()}\n" +
            "Bateria: $lvl%   Temperatura: $temp °C\n" +
            "Taxa de atualização da tela: ${hz.toInt()} Hz\n" +
            "Economia de bateria: ${if (eco) "ativa" else "desativada"}\n" +
            "Roblox: ${if (installed(RBX)) "instalado" else "não instalado"}"
    }

    private fun edit(hint: String) = EditText(this).apply { this.hint = hint; textSize = 14f; setSingleLine(); setTextColor(ink) }
    private fun reload() { views[2] = fastflags(); show(2) }

    private fun fastflags(): View {
        val (sv, col) = page("FastFlags", "Ajustes e flags personalizadas. O JSON sai no formato que o Roblox exige (valores em texto).")
        val pr = LinearLayout(this)
        fun preset(n: String, ids: List<String>) = pr.addView(btn(n) { flagOn.clear(); flagOn.addAll(ids); reload() }, LinearLayout.LayoutParams(0, -2, 1f))
        preset("Equilibrado", listOf(flagKeys[0], flagKeys[1], flagKeys[2]))
        preset("Máximo", flagKeys.filter { it != flagKeys[5] })
        preset("Vulkan", listOf(flagKeys[5]))
        col.put(pr)
        val c = card(); val js = tv(buildJson(), 12f, mono = true).apply { setPadding(dp(14), dp(12), dp(14), dp(12)) }
        flagKeys.forEach { k -> c.addView(row(k, k in flagOn) { b -> if (b) flagOn.add(k) else flagOn.remove(k); js.text = buildJson() }) }
        col.put(c)

        col.put(tv("Flags personalizadas", 15f, bold = true), 6)
        val cc = card().apply { setPadding(dp(14), dp(8), dp(14), dp(12)) }
        val kn = edit("Nome da flag"); val kv = edit("Valor (ex.: True ou 0)")
        cc.addView(kn); cc.addView(kv)
        cc.addView(btn("Adicionar flag") {
            val n = kn.text.toString().trim()
            if (n.isNotEmpty()) { custom[n] = kv.text.toString().trim(); saveCustom(); reload() }
        })
        custom.forEach { (n, value) ->
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
            val ok = n in allow
            r.addView(tv("$n = $value\n" + if (ok) "permitida" else "fora da lista: será ignorada", 12f, if (ok) ink else Color.parseColor("#B26A00"), mono = true), LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(btn("Remover") { custom.remove(n); saveCustom(); reload() })
            cc.addView(r)
        }
        col.put(cc)
        col.put(btn("Importar JSON da área de transferência") {
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val o = JSONObject(cm.primaryClip!!.getItemAt(0).text.toString())
                o.keys().forEach { key -> custom[key] = fmt(o.get(key)) }
                saveCustom(); reload()
            } catch (e: Exception) { Toast.makeText(this, "JSON inválido na área de transferência", Toast.LENGTH_LONG).show() }
        }, 12)

        val jc = card(); jc.addView(js); col.put(jc)
        val status = tv("", 12f, mute)
        col.put(btn("Aplicar no Roblox (root)", true) { status.text = "Aplicando..."; applyRoot { status.text = it } }, 8)
        col.put(btn("Copiar JSON") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("json", buildJson()))
            Toast.makeText(this, "JSON copiado", Toast.LENGTH_SHORT).show()
        }, 8)
        col.put(btn("Verificar root") {
            Thread { val (ok, _) = su("id"); h.post { status.text = if (ok) "Root disponível" else "Root não detectado" } }.start()
        }, 8)
        col.put(status, 8)
        col.put(tv("Desde 29/09/2025 o Roblox ignora flags fora de uma lista permitida, inclusive no Bloxstrap. A lista pode ter mudado: confira no DevForum do Roblox. Sem root, o Android não deixa nenhum app gravar na pasta do Roblox.", 12f, mute))
        return sv
    }

    private fun fonte(): View {
        val (sv, col) = page("Fonte do jogo", "Importe um arquivo .ttf ou .otf para usar com um cliente compatível.")
        fontInfo = tv("", 14f, bold = true); fontPv = tv("Placar: 1.250 pontos, bloxBrasil", 20f)
        val c = card().apply { setPadding(dp(14), dp(12), dp(14), dp(12)) }
        c.addView(fontInfo); c.addView(fontPv); col.put(c)
        col.put(btn("Escolher arquivo de fonte", true) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 7)
        }, 8)
        col.put(btn("Remover fonte") { File(filesDir, "custom_font").delete(); prefs.edit().remove("font").apply(); refreshFont() })
        refreshFont()
        return sv
    }

    private fun refreshFont() {
        val f = File(filesDir, "custom_font")
        val name = prefs.getString("font", null)
        if (f.exists() && name != null) {
            fontInfo?.text = "Fonte: $name"
            try { fontPv?.typeface = Typeface.createFromFile(f) } catch (e: Exception) { fontPv?.typeface = Typeface.DEFAULT }
        } else { fontInfo?.text = "Fonte padrão do Roblox"; fontPv?.typeface = Typeface.DEFAULT }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req != 7 || res != RESULT_OK || uri == null) return
        try {
            val dest = File(filesDir, "custom_font")
            contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            Typeface.createFromFile(dest)
            var name = "fonte"
            contentResolver.query(uri, null, null, null, null)?.use { if (it.moveToFirst()) name = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) }
            prefs.edit().putString("font", name).apply(); refreshFont()
        } catch (e: Exception) {
            File(filesDir, "custom_font").delete()
            Toast.makeText(this, "Arquivo de fonte inválido", Toast.LENGTH_LONG).show()
        }
    }

    private fun show(i: Int) {
        cur = i; content.removeAllViews(); content.addView(views[i])
        navItems.forEachIndexed { j, t -> t.setTextColor(if (j == i) acc else mute) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        root.addView(tv("bloxBrasil", 22f, bold = true).apply { setPadding(dp(16), dp(14), dp(16), dp(10)) })
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        loadCustom(); views.addAll(listOf(otimizar(), desempenho(), fastflags()))
        val nav = LinearLayout(this).apply { setBackgroundColor(Color.WHITE) }
        navItems = listOf("Otimizar", "Desempenho", "FastFlags").mapIndexed { i, n ->
            tv(n, 13f, mute, bold = true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(16)); setOnClickListener { show(i) }
                nav.addView(this, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }
        root.addView(nav)
        setContentView(root); show(0)
        h.post(object : Runnable { override fun run() { if (perfTv?.isAttachedToWindow == true) tickPerf(); h.postDelayed(this, 2000) } })
    }
}
