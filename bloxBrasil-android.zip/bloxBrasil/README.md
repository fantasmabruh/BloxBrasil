# bloxBrasil
App Android (Kotlin, sem bibliotecas externas). Compilacao: suba esta pasta em um repositorio do GitHub,
abra Actions > Build APK > Run workflow e baixe o artefato bloxBrasil-apk.
